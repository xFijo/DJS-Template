module.exports = {
    token: process.env.TOKEN, // token
    prefix: '!', //prefix 
    owners: [''], //list of bot owners
    commandCooldown: 4 //cooldown
}
