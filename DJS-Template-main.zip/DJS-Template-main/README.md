# DJS-Template
Good template for developing your discord bot :p
